package Game;

import java.awt.event.KeyEvent;

public class PC extends Entity {
	private int dx;
	private int dy;
	private int direction;
	private boolean moving;
	private boolean dirchange;

	
	public PC(int x,int y) {
		super(x,y);
		
		initPC();
	}
	
	private void initPC() {
		loadImage("src/Image/tile001.png");
		getImageDim();
	}
	public void move(int frame_count) {
		if (dirchange) {
			frame_count = 0;
			dirchange = false;
		}
		
		if (moving == false) {
			switch (direction) {
			case 0:
				loadImage("src/Image/tile001.png");
				break;
			case 1:
				loadImage("src/Image/tile004.png");
				break;
			case 2:
				loadImage("src/Image/tile007.png");
				break;
			case 3:
				loadImage("src/Image/tile010.png");
				break;
				}
			} else {
				switch(direction) {
				case 0:
					switch(frame_count % 21) {
					case 21:
						loadImage("src/Image/tile000.png");
					break;
					case 14:
						loadImage("src/Image/tile001.png");
						break;
					case 7:
						loadImage("src/Image/tile002.png");
						break;
					case 0:
						loadImage("src/Image/tile001.png");
						break;
					}
					break;
				case 1:
					switch(frame_count % 21) {
					case 21:
						loadImage("src/Image/tile003.png");
					break;
					case 14:
						loadImage("src/Image/tile004.png");
						break;
					case 7:
						loadImage("src/Image/tile005.png");
						break;
					case 0:
						loadImage("src/Image/tile004.png");
						break;
					}
					break;
				case 2:
					switch(frame_count % 21) {
					case 21:
						loadImage("src/Image/tile006.png");
					break;
					case 14:
						loadImage("src/Image/tile007.png");
						break;
					case 7:
						loadImage("src/Image/tile008.png");
						break;
					case 0:
						loadImage("src/Image/tile007.png");
						break;
					}
					break;
				case 3:
					switch(frame_count % 21) {
					case 21:
						loadImage("src/Image/tile009.png");
					break;
					case 14:
						loadImage("src/Image/tile010.png");
						break;
					case 7:
						loadImage("src/Image/tile011.png");
						break;
					case 0:
						loadImage("src/Image/tile010.png");
						break;
					}
					break;
				}
				
			}
		//else moving
		x_pos += dx;
		y_pos += dy;
	}
	public void keyPressed(KeyEvent e) {
		int key = e.getKeyCode();
		
		if(key == KeyEvent.VK_W) {
			dy = -2;
			this.moving = true;
			if(direction != 3) {
				dirchange = true;
			}
			this.direction = 3;
		}
		if (key == KeyEvent.VK_S) {
			dy = 2;
			this.moving = true;
			if(direction != 0) {
				dirchange = true;
			}
			this.direction = 0;
		}
		if (key == KeyEvent.VK_A) {
			dx = -2;
			this.moving = true;
			if(direction != 1) {
				dirchange = true;
			}
			this.direction = 1;
		}
		if (key == KeyEvent.VK_D) {
			dx = 2;
			this.moving = true;
			if(direction != 2) {
				dirchange = true;
			}
			this.direction = 2;
		}
		
	}
	public void keyReleased(KeyEvent e) {
		int key = e.getKeyCode();
		
		if (key == KeyEvent.VK_W) {
			dy = 0;

		}
		if (key == KeyEvent.VK_S) {
			dy = 0;

		}
		if (key == KeyEvent.VK_A) {
			dx = 0;

		}
		if (key == KeyEvent.VK_D) {
			dx = 0;

		}
		if (dx == 0 && dy == 0 ) {
			this.moving = false;
		} 
		if(dx < 0) {
			this.direction = 1;
		}
		if (dy < 0) {
			this.direction = 3;
		}
		if (dx > 0) {
			this.direction = 2;
		}
		if (dy > 0) {
			this.direction = 0;
		}
	}

}
