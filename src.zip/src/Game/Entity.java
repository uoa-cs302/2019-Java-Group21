package Game;

public class Entity extends Sprite {
	
	//needs to have Health,Damage,etc.
	
	public Entity(int x,int y) {
		super(x,y);
		
	}
}
